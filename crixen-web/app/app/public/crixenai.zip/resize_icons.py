
import os
import sys
from PIL import Image

def resize_icon(input_path, output_dir, sizes=[16, 32, 48, 128]):
    try:
        img = Image.open(input_path)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        
        for size in sizes:
            resized_img = img.resize((size, size), Image.Resampling.LANCZOS)
            output_path = os.path.join(output_dir, f"icon{size}.png")
            resized_img.save(output_path)
            print(f"Saved {output_path}")
            
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    input_image = "/home/x-5194/.gemini/antigravity/brain/a6f4943b-0ac1-4f9e-aef5-783432e889ce/uploaded_media_1770098612036.png"
    output_directory = "/home/x-5194/dump/instagram-ai-comment-assistant/assets/icons"
    resize_icon(input_image, output_directory)
