export const CONFIG = {
    API_URL: 'http://localhost:3000/api/v1/ai/generate',
    NEAR_AI_ENDPOINT: 'https://cloud-api.near.ai/v1/chat/completions'
};
